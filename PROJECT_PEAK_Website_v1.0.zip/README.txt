PROJECT PEAK WEBSITE

Open index.html in a browser to preview the website.
The downloads folder contains the v1.0 optimizer ZIP linked by the Download buttons.
To publish it online, upload the contents of this folder to a static website host.
