PROJECT PEAK - SAFE PC OPTIMIZER

1. Extract this folder if it is inside a ZIP.
2. Double-click START_PROJECT_PEAK.bat.
3. Choose 1 first to scan your PC and create a report.
4. The report will be saved in Desktop\Project_PEAK_Reports.
5. Review the report before making any bigger changes.

For a restore point, right-click START_PROJECT_PEAK.bat and choose
"Run as administrator", then choose option 2.

SAFETY:
- This starter version does not overclock, disable Windows services,
  disable antivirus/firewall, alter drivers, or delete personal files.
- Cleanup only targets your own TEMP folder and only files older than 7 days.
- It cannot guarantee higher FPS. It helps identify bottlenecks and perform
  conservative maintenance.
- Do not run random "debloat" scripts or registry packs alongside it.
