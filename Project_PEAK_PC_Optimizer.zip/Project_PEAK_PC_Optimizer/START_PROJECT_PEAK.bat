@echo off
title PROJECT PEAK PC OPTIMIZER
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Project_PEAK.ps1"
if errorlevel 1 (
  echo.
  echo Project PEAK closed with an error. You can take a picture of this screen.
  pause
)
