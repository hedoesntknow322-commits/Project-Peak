# PROJECT PEAK - Safe Windows PC Optimizer
# Designed for Windows 10/11. Makes conservative changes only.
# It does NOT disable Windows services, edit GPU drivers, overclock hardware,
# change security settings, or delete personal files.

$ErrorActionPreference = "Continue"
$ReportDir = Join-Path $env:USERPROFILE "Desktop\Project_PEAK_Reports"
New-Item -ItemType Directory -Path $ReportDir -Force | Out-Null
$Stamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$Report = Join-Path $ReportDir "PEAK_Report_$Stamp.txt"

function Write-Report {
    param([string]$Text)
    $Text | Tee-Object -FilePath $Report -Append
}

function Header([string]$Title) {
    Clear-Host
    Write-Host ""
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host "       PROJECT PEAK PC OPTIMIZER" -ForegroundColor Cyan
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host $Title -ForegroundColor Yellow
    Write-Host ""
}

function Get-SystemScan {
    Header "SYSTEM SCAN"
    Write-Report "PROJECT PEAK SYSTEM REPORT - $(Get-Date)"
    Write-Report "Computer: $env:COMPUTERNAME"
    Write-Report ""

    $os = Get-CimInstance Win32_OperatingSystem
    $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
    $ramGB = [math]::Round($os.TotalVisibleMemorySize / 1MB, 1)
    Write-Report "WINDOWS: $($os.Caption) | Version $($os.Version)"
    Write-Report "CPU: $($cpu.Name)"
    Write-Report "RAM: $ramGB GB"
    Write-Report "GPU:"
    Get-CimInstance Win32_VideoController | ForEach-Object {
        Write-Report " - $($_.Name) | Driver: $($_.DriverVersion) | Adapter RAM reported: $([math]::Round($_.AdapterRAM / 1GB, 2)) GB"
    }

    Write-Report ""
    Write-Report "DRIVES:"
    Get-CimInstance Win32_DiskDrive | ForEach-Object {
        Write-Report " - $($_.Model) | $([math]::Round($_.Size / 1GB, 1)) GB | Interface: $($_.InterfaceType)"
    }
    Get-PSDrive -PSProvider FileSystem | ForEach-Object {
        if ($_.Used -ne $null -and $_.Free -ne $null) {
            Write-Report " - $($_.Name): free $([math]::Round($_.Free / 1GB, 1)) GB / used $([math]::Round($_.Used / 1GB, 1)) GB"
        }
    }

    Write-Report ""
    Write-Report "TOP CPU PROCESSES:"
    Get-Process | Sort-Object CPU -Descending | Select-Object -First 10 |
        ForEach-Object { Write-Report (" - {0} | CPU time: {1}" -f $_.ProcessName, [math]::Round($_.CPU, 1)) }

    Write-Report ""
    Write-Report "STARTUP ITEMS (review these manually; nothing was disabled):"
    try {
        Get-CimInstance Win32_StartupCommand | ForEach-Object {
            Write-Report " - $($_.Name) | $($_.Command)"
        }
    } catch {
        Write-Report "Startup list could not be read."
    }

    Write-Report ""
    Write-Report "POWER PLAN:"
    powercfg /getactivescheme 2>&1 | ForEach-Object { Write-Report "$_" }

    Write-Report ""
    Write-Report "NOTES:"
    Write-Report "- This scan does not benchmark FPS. Run the same game scene before and after changes."
    Write-Report "- A reported adapter-memory value can be inaccurate for integrated graphics."
    Write-Report "- High CPU and GPU use together can indicate a hardware limit, not a Windows setting."
    Write-Host "Scan complete. Report saved here:" -ForegroundColor Green
    Write-Host $Report -ForegroundColor White
    Write-Host ""
    Read-Host "Press Enter to return to the menu"
}

function New-RestorePoint {
    Header "RESTORE POINT"
    try {
        Checkpoint-Computer -Description "Before Project PEAK optimization" -RestorePointType "MODIFY_SETTINGS"
        Write-Host "Restore point created." -ForegroundColor Green
        Write-Report "Restore point requested at $(Get-Date)."
    } catch {
        Write-Host "Windows could not create a restore point." -ForegroundColor Yellow
        Write-Host "This can happen if System Protection is off or the script is not running as administrator."
        Write-Host $_.Exception.Message
    }
    Read-Host "Press Enter to return to the menu"
}

function Safe-Cleanup {
    Header "SAFE CLEANUP"
    Write-Host "This removes only files older than 7 days from your own temporary folder."
    Write-Host "It will not delete Downloads, Documents, photos, games, or browser data."
    $confirm = Read-Host "Type CLEAN to continue"
    if ($confirm -cne "CLEAN") {
        Write-Host "Cancelled."
        Start-Sleep -Seconds 1
        return
    }

    $tempPath = $env:TEMP
    $cutoff = (Get-Date).AddDays(-7)
    $removed = 0
    $freed = 0
    Get-ChildItem -LiteralPath $tempPath -File -Recurse -Force -ErrorAction SilentlyContinue |
        Where-Object { $_.LastWriteTime -lt $cutoff } |
        ForEach-Object {
            try {
                $len = $_.Length
                Remove-Item -LiteralPath $_.FullName -Force -ErrorAction Stop
                $removed++
                $freed += $len
            } catch { }
        }

    Write-Report "SAFE CLEANUP - $(Get-Date)"
    Write-Report "Temporary files removed: $removed"
    Write-Report "Approximate space freed: $([math]::Round($freed / 1MB, 1)) MB"
    Write-Host "Cleanup finished." -ForegroundColor Green
    Write-Host "Files removed: $removed"
    Write-Host "Approximate space freed: $([math]::Round($freed / 1MB, 1)) MB"
    Write-Host "A few files may remain because Windows or an app is using them."
    Read-Host "Press Enter to return to the menu"
}

function Basic-Maintenance {
    Header "BASIC MAINTENANCE"
    Write-Host "This refreshes the Windows DNS cache only. It does not change network settings."
    try {
        Clear-DnsClientCache
        Write-Host "DNS cache refreshed." -ForegroundColor Green
        Write-Report "DNS cache refreshed at $(Get-Date)."
    } catch {
        Write-Host "Could not refresh DNS cache: $($_.Exception.Message)" -ForegroundColor Yellow
    }
    Write-Host ""
    Write-Host "No services or security protections were disabled."
    Read-Host "Press Enter to return to the menu"
}

while ($true) {
    Header "SAFE SYSTEM-WIDE OPTIMIZATION"
    Write-Host "1. Scan my PC and create a report"
    Write-Host "2. Create a Windows restore point (run as administrator)"
    Write-Host "3. Safe temporary-file cleanup"
    Write-Host "4. Basic network maintenance"
    Write-Host "5. Open report folder"
    Write-Host "0. Exit"
    Write-Host ""
    $choice = Read-Host "Choose an option"
    switch ($choice) {
        "1" { Get-SystemScan }
        "2" { New-RestorePoint }
        "3" { Safe-Cleanup }
        "4" { Basic-Maintenance }
        "5" { Start-Process explorer.exe $ReportDir }
        "0" { break }
        default { Write-Host "Choose 0, 1, 2, 3, 4, or 5."; Start-Sleep -Seconds 1 }
    }
}
